// =============================================================
//  Station ALMA-7, Part III: The Repair Fleet
//  iOS Mobile Development · Module 5 · Lab Assignment
// =============================================================


// MARK: - =================== STARTER DATA ===================
// MARK: - Do not modify anything in this section

let fleetData: [(kind: String, id: String, charge: Int)] = [
    (kind: "welder",  id: "W-1", charge: 80),
    (kind: "scanner", id: "S-1", charge: 45),
    (kind: "cargo",   id: "C-1", charge: 100),
    (kind: "welder",  id: "W-2", charge: 15),
    (kind: "scanner", id: "S-2", charge: 60),
    (kind: "tug",     id: "T-1", charge: 50)
]

let sensorData: [(id: String, charge: Int)] = [
    (id: "hull-cam", charge: 12),
    (id: "thermal",  charge: 77)
]

struct LegacyBeacon {
    let name: String
    let signalStrength: Int
}

let beacon = LegacyBeacon(name: "ALMA-BEACON", signalStrength: 8)

print("Fleet registry online: \(fleetData.count) drone records, \(sensorData.count) sensors, beacon \(beacon.name).")

// MARK: - ================= END OF STARTER DATA =================


// MARK: - =================== YOUR SOLUTION ===================


// MARK: Level 1 · The Power Cell

// Why a class and not a struct here?  -> класс это ссылка, батарейка одна на дрона и все видят один заряд, структура бы копировалась
final class PowerCell {
    private var charge: Int

    init(charge: Int) {
        if charge < 0 {
            self.charge = 0
        } else if charge > 100 {
            self.charge = 100
        } else {
            self.charge = charge
        }
    }

    func level() -> Int {
        return charge
    }

    func spend(_ amount: Int) -> Bool {
        if amount <= 0 {
            return false
        }
        if amount > charge {
            return false
        }
        charge -= amount
        return true
    }

    func recharge(by amount: Int) {
        if amount <= 0 {
            return
        }
        charge += amount
        if charge > 100 {
            charge = 100
        }
    }
}

// Encapsulation proof (leave this commented, with the compiler error):
// let cell = PowerCell(charge: 50)
// cell.charge = 100
// error: 'charge' is inaccessible due to 'private' protection level


// MARK: Level 2 · The Fleet

// 2.1  What does `final` on runOnce() buy you?  -> подклассы меняют стоимость и работу но не сам ритуал смены, никто не сломает порядок spend потом performTask
class Drone {
    let id: String
    let cell: PowerCell

    init(id: String, cell: PowerCell) {
        self.id = id
        self.cell = cell
    }

    var powerCost: Int {
        return 10
    }

    var statusLine: String {
        return "\(id): \(cell.level())% \(cell.level().powerBar)"
    }

    func performTask() -> Int {
        return 0
    }

    final func runOnce() -> Int {
        let spent = cell.spend(powerCost)
        if !spent {
            return 0
        }
        return performTask()
    }
}

// 2.2
final class WelderDrone: Drone {
    override var powerCost: Int { return 25 }

    override func performTask() -> Int {
        return 40
    }

    func weldSeam() -> String {
        return "\(id) welded a seam"
    }
}

class ScannerDrone: Drone {
    override var powerCost: Int { return 10 }

    override func performTask() -> Int {
        return 15
    }

    override var statusLine: String {
        return super.statusLine + " [scanner]"
    }
}

final class CargoDrone: Drone {
    override var powerCost: Int { return 20 }

    override func performTask() -> Int {
        return 25
    }
}

// 2.3
func makeDrone(kind: String, id: String, charge: Int) -> Drone? {
    let cell = PowerCell(charge: charge)
    if kind == "welder" {
        return WelderDrone(id: id, cell: cell)
    } else if kind == "scanner" {
        return ScannerDrone(id: id, cell: cell)
    } else if kind == "cargo" {
        return CargoDrone(id: id, cell: cell)
    } else {
        return nil
    }
}

var fleet: [Drone] = []
for record in fleetData {
    if let drone = makeDrone(kind: record.kind, id: record.id, charge: record.charge) {
        fleet.append(drone)
    } else {
        print("warning: skipped \(record.id) unknown kind \(record.kind)")
    }
}


// MARK: Level 3 · The Shift

func runShift(_ fleet: [Drone], rounds: Int) -> Int {
    var total = 0
    var r = 0
    while r < rounds {
        for drone in fleet {
            total += drone.runOnce()
        }
        r += 1
    }
    return total
}

let A = runShift(fleet, rounds: 3)
print("total work units: \(A)")

for drone in fleet {
    print(drone.statusLine)
}

var B = 0
for drone in fleet {
    B += drone.cell.level()
}
print("total remaining charge: \(B)")

var C = 0
for drone in fleet {
    if drone.cell.level() >= drone.powerCost {
        C += 1
    }
}
print("drones that can run one more task: \(C)")


// MARK: Level 4 · Diagnostics

// 4.1
protocol Diagnosable {
    var componentID: String { get }
    var statusCode: Int { get }
    func diagnose() -> String
}

// 4.2
// Why does Drone implement recharge(by:) without `mutating`?  -> класс это ссылочный тип, мутирующий метод по умолчанию меняет то на что ссылаемся, mutating не нужен
protocol Rechargeable {
    mutating func recharge(by amount: Int)
}

extension Drone: Diagnosable, Rechargeable {
    var componentID: String {
        return id
    }

    var statusCode: Int {
        return statusCode(for: cell.level())
    }

    func recharge(by amount: Int) {
        cell.recharge(by: amount)
    }
}

struct SensorModule: Diagnosable, Rechargeable {
    let componentID: String
    var chargeLevel: Int

    var statusCode: Int {
        return statusCode(for: chargeLevel)
    }

    mutating func recharge(by amount: Int) {
        if amount <= 0 {
            return
        }
        chargeLevel += amount
        if chargeLevel > 100 {
            chargeLevel = 100
        }
    }
}

var sensors: [SensorModule] = []
for s in sensorData {
    sensors.append(SensorModule(componentID: s.id, chargeLevel: s.charge))
}

// 4.3
// Why could [Drone] never have held the sensors?  -> sensorModule это структура и не наследник Drone, только протокол может смешать класс и структуру в одном массиве
func diagnosticsReport(_ components: [Diagnosable]) -> String {
    var report = "=== diagnostics ===\n"
    for c in components {
        report += c.diagnose() + "\n"
    }
    return report
}


// MARK: Level 5 · Shared Behaviour

// 5.1 · default diagnose() + the single home of the Health Rule
extension Diagnosable {
    func diagnose() -> String {
        return "\(componentID): code \(statusCode)"
    }

    // the only place with the health rule
    func statusCode(for level: Int) -> Int {
        if level < 20 {
            return 2
        } else if level < 50 {
            return 1
        } else {
            return 0
        }
    }
}

// 5.2 · the beacon you cannot edit
extension LegacyBeacon: Diagnosable {
    var componentID: String {
        return name
    }

    var statusCode: Int {
        return statusCode(for: signalStrength)
    }

    func diagnose() -> String {
        return "legacy \(name): code \(statusCode) signal \(signalStrength)"
    }
}

// 5.3
extension Int {
    var powerBar: String {
        var n = self / 10
        if n < 0 {
            n = 0
        }
        if n > 10 {
            n = 10
        }
        var s = ""
        var i = 0
        while i < 10 {
            if i < n {
                s += "#"
            } else {
                s += "."
            }
            i += 1
        }
        return s
    }
}

var allComponents: [Diagnosable] = []
for drone in fleet {
    allComponents.append(drone)
}
for sensor in sensors {
    allComponents.append(sensor)
}
allComponents.append(beacon)

print(diagnosticsReport(allComponents))

var D = 0
for c in allComponents {
    D += c.statusCode
}
print("sum of status codes: \(D)")


// MARK: Level 6 · Incident Reports
// Two of these do not compile. Two compile and lie.
// For each: expectation, actual behaviour, the language rule, the fix.

/*
// Report 1
class PatchDrone: Drone {
    func performTask() -> Int {
        return 30
    }
}

// Report 2
final class HeavyWelder: WelderDrone {
    override func runOnce() -> Int {
        return 999
    }
}

// Report 3
let reportFleet: [Drone] = [WelderDrone(id: "W-9", cell: PowerCell(charge: 100))]
let first = reportFleet[0]
print(first.weldSeam())

// Report 4
protocol Labelled {
    var componentID: String { get }
}

extension Labelled {
    func label() -> String { "generic component" }
}

struct Thruster: Labelled {
    let componentID: String
    func label() -> String { "thruster \(componentID)" }
}

let parts: [Labelled] = [Thruster(componentID: "T-1")]
print(parts[0].label())
*/

// Report 1
class PatchDrone: Drone {
    override func performTask() -> Int {
        return 30
    }
}

// Expectation: PatchDrone overrides performTask() and returns 30
// Actual behaviour: Overriding declaration requires an 'override' keyword
// Language rule: If a subclass method has the same signature as a superclass method, Swift requires the override keyword — it is an explicit confirmation of the intent to override
// Fix: add override


// Report 2
final class HeavyWelder: Drone {
    override var powerCost: Int { return 50 }
    override func performTask() -> Int { return 999 }
}

// Expectation: HeavyWelder returns 999 from runOnce(), bypassing the normal shift logic
// Actual behaviour: Inheritance from a final class 'WelderDrone' and Instance method overrides a 'final' instance method
// Language rule: final on a class forbids subclassing. final on a method forbids overriding. Both mechanisms protect behaviour from being changed by subclasses
// Fix: Do not subclass WelderDrone; make HeavyWelder a direct subclass of Drone and override powerCost / performTask instead of runOnce()

// Report 3
let reportFleet: [Drone] = [WelderDrone(id: "W-9", cell: PowerCell(charge: 100))]
let first = reportFleet[0]
if let welder = first as? WelderDrone {
    print(welder.weldSeam())
}

// Expectation: first is a WelderDrone, so weldSeam() is callable
// Actual behaviour: Value of type 'Drone' has no member 'weldSeam'
// Language rule: The array is declared as [Drone]. The compiler sees the static type of the element — Drone — and only allows calling what Drone has. weldSeam() exists only on WelderDrone, so the compiler cannot see it
// Fix: use as? to safely cast to WelderDrone

// Report 4
protocol Labelled {
    var componentID: String { get }
    func label() -> String
}

extension Labelled {
    func label() -> String { "generic component" }
}

struct Thruster: Labelled {
    let componentID: String
    func label() -> String { "thruster \(componentID)" }
}

let parts: [Labelled] = [Thruster(componentID: "T-1")]
print(parts[0].label())

// Expectation: Prints "thruster T-1" — Thruster's own label()
// Actual behaviour: Compiles. Prints "generic component"
// Language rule: Static vs dynamic dispatch. A method that is not declared in the protocol but lives only in an extension is not added to the witness table. When called through a protocol-typed value, Swift uses static dispatch and calls the extension's implementation, ignoring the concrete type's method.
// Fix: Declare label() inside the protocol — then dispatch becomes dynamic


// MARK: Finale · Mission Code

let missionCode = "\(A)-\(B)-\(C)-\(D)"
print("MISSION CODE: \(missionCode)")


// MARK: Bonus

// ---------- 1. two ways to forbid using Drone directly ----------

// runtime: fatalError in init if type(of: self) == Drone.self
class DroneR {
    let id: String
    let cell: PowerCell
    init(id: String, cell: PowerCell) {
        if type(of: self) == DroneR.self {
            fatalError("cannot instantiate DroneR directly")
        }
        self.id = id
        self.cell = cell
    }
    var powerCost: Int { return 10 }
    func performTask() -> Int { return 0 }
    final func runOnce() -> Int {
        let spent = cell.spend(powerCost)
        if !spent { return 0 }
        return performTask()
    }
}

// compile time: hide the designated init behind a fileprivate one so outside
// code cannot build a DroneC even though the type is visible, subclasses in
// the same file can still call it
class DroneC {
    let id: String
    let cell: PowerCell
    fileprivate init(id: String, cell: PowerCell) {
        self.id = id
        self.cell = cell
    }
    var powerCost: Int { return 10 }
    func performTask() -> Int { return 0 }
    final func runOnce() -> Int {
        let spent = cell.spend(powerCost)
        if !spent { return 0 }
        return performTask()
    }
}


// ---------- 2. protocol-based redesign ----------

protocol DroneProtocol {
    var id: String { get }
    var cell: PowerCell { get }
    var powerCost: Int { get }
    var tag: String { get }
    var statusCode: Int { get }
    func performTask() -> Int
}

extension DroneProtocol {
    // ritual lives here once, exactly like runOnce did on the class
    func runOnce() -> Int {
        let spent = cell.spend(powerCost)
        if !spent {
            return 0
        }
        return performTask()
    }

    var statusLine: String {
        return "\(id): \(cell.level())% \(cell.level().powerBar)\(tag)"
    }
}

struct WelderDroneP: DroneProtocol, Diagnosable, Rechargeable {
    let id: String
    let cell: PowerCell
    var powerCost: Int { return 25 }
    var tag: String { return "" }
    var componentID: String { return id }
    var statusCode: Int { return statusCode(for: cell.level()) }
    func performTask() -> Int { return 40 }
    func weldSeam() -> String { return "\(id) welded a seam" }

    mutating func recharge(by amount: Int) {
        cell.recharge(by: amount)
    }
}

struct ScannerDroneP: DroneProtocol, Diagnosable, Rechargeable {
    let id: String
    let cell: PowerCell
    var powerCost: Int { return 10 }
    var tag: String { return " [scanner]" }
    var componentID: String { return id }
    var statusCode: Int { return statusCode(for: cell.level()) }
    func performTask() -> Int { return 15 }

    mutating func recharge(by amount: Int) {
        cell.recharge(by: amount)
    }
}

struct CargoDroneP: DroneProtocol, Diagnosable, Rechargeable {
    let id: String
    let cell: PowerCell
    var powerCost: Int { return 20 }
    var tag: String { return "" }
    var componentID: String { return id }
    var statusCode: Int { return statusCode(for: cell.level()) }
    func performTask() -> Int { return 25 }

    mutating func recharge(by amount: Int) {
        cell.recharge(by: amount)
    }
}

func makeDroneP(kind: String, id: String, charge: Int) -> DroneProtocol? {
    let cell = PowerCell(charge: charge)
    if kind == "welder" { return WelderDroneP(id: id, cell: cell) }
    if kind == "scanner" { return ScannerDroneP(id: id, cell: cell) }
    if kind == "cargo" { return CargoDroneP(id: id, cell: cell) }
    return nil
}

func runShiftP(_ fleet: [DroneProtocol], rounds: Int) -> Int {
    var total = 0
    var r = 0
    while r < rounds {
        for d in fleet {
            total += d.runOnce()
        }
        r += 1
    }
    return total
}

var fleetP: [DroneProtocol] = []
for record in fleetData {
    if let d = makeDroneP(kind: record.kind, id: record.id, charge: record.charge) {
        fleetP.append(d)
    } else {
        print("warning: skipped \(record.id) unknown kind \(record.kind)")
    }
}

let A2 = runShiftP(fleetP, rounds: 3)
print("proto total work units: \(A2)")

var B2 = 0
for d in fleetP { B2 += d.cell.level() }
print("proto total remaining charge: \(B2)")

var C2 = 0
for d in fleetP {
    if d.cell.level() >= d.powerCost {
        C2 += 1
    }
}
print("proto drones that can run one more task: \(C2)")

var D2 = 0
for d in fleetP { D2 += d.statusCode }
for s in sensors { D2 += s.statusCode }
D2 += beacon.statusCode
print("proto sum of status codes: \(D2)")


// ---------- 3. comparison ----------

// class version is shorter and lets every drone share one mutable cell through
// reference semantics, which is exactly what the fleet needs here.
// protocol + struct version is safer for testing and value semantics, and it
// can mix with any other type that conforms, but shared mutable state has to
// go through a reference box (like our PowerCell) or an actor to stay in sync.
// for this station i would keep the class because the cell is shared mutable
// state. if drones later needed to sync batteries across the station i would
// switch to the protocol design and wrap the shared state in a reference type.


// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1. a class satisfies mutating protocol requirements without the keyword
    because classes are reference types, mutating just means changes self
    which for a class is always allowed. a struct is a value type so it must
    write mutating to say it modifies its own stored properties.

 2. inheritance gives shared stored properties and super calls, so subclasses
    can reuse and extend base behaviour. protocols give a common interface
    for unrelated types like a class and a struct in one array, which
    inheritance can never do.

 3. final prevents overriding a method and subclassing a class. making
    runOnce final protected the shift ritual so no subclass could change
    the order of spend then performTask or return something else.

 4. in report 4 the protocol extension method won because label() was not
    a protocol requirement, only a method provided by the extension. when
    called through the protocol type swift uses static dispatch and picks
    the extension version instead of the structs own method.
*/
