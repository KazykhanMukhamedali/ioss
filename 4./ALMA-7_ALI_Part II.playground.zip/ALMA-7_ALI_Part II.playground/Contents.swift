// =============================================================

//  Station ALMA-7, Part II: The Teleporter Incident
//  iOS Mobile Development · Module 4 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Part2_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER DATA section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Default to struct. Use class only where the task says so.
// =============================================================



// **MARK: - =================== STARTER DATA ===================**

// **MARK: - Do not modify anything in this section**

/// Splits a line into fields.
/// fields("crate:101:120") -> ["crate", "101", "120"]
/// fields("livestock:lab mice:12:2") -> ["livestock", "lab mice", "12", "2"]
/// fields("junk") -> ["junk"]

func fields(_ line: String, separatedBy separator: Character = ":") -> [String] {
    var result: [String] = []
    var current = ""

    for character in line {
        if character == separator {
            result.append(current)
            current = ""
        } else {
            current.append(character)
        }
    }

    result.append(current)
    return result
}

/// Cargo manifest as recovered from the damaged recorder.

let rawManifest = [
    "crate:101:120",
    "container:KZ-ALM-7:340",
    "livestock:lab mice:12:2",
    "???-corrupted-line",
    "crate:102:75",
    "container:KZ-ALM-9:410",
    "livestock:ficus:3:5",
    "crate:103:260",
    "crate:104:abc",
    ""
]

/// Oxygen readings. One of these deck names is not a real deck.

let deckReadings: [(deck: String, oxygen: Int)] = [
    (deck: "bridge", oxygen: 78),
    (deck: "lab", oxygen: 64),
    (deck: "greenhouse", oxygen: 55),
    (deck: "cargo", oxygen: 12),
    (deck: "medbay", oxygen: 90),
    (deck: "engine", oxygen: 41)
]

/// Crew records, straight from the personnel file.

let crewData: [(name: String, deck: String, oxygen: Int)] = [
    (name: "Timur", deck: "engine", oxygen: 62),
    (name: "Dana", deck: "lab", oxygen: 48),
    (name: "Aigerim", deck: "bridge", oxygen: 91),
    (name: "Nurlan", deck: "cargo", oxygen: 17)
]

print(
    "ALMA-7 recorder online: \(rawManifest.count) manifest lines, \(deckReadings.count) readings, \(crewData.count) crew records."
)

// **MARK: - ================= END OF STARTER DATA =================**



// **MARK: - =================== YOUR SOLUTION ===================**



// **MARK: Level 1 · The Deck Register**

// 1.1

enum Deck: String, CaseIterable {
    case bridge
    case lab
    case cargo
    case medbay
    case engine

    // приоритет эвакуации: чем меньше число, тем раньше спасаем
    var evacuationPriority: Int {
        switch self {
        case .bridge:
            return 1
        case .medbay:
            return 2
        case .lab:
            return 3
        case .engine:
            return 4
        case .cargo:
            return 5
        }
    }
}

// Demonstration of Deck

for deck in Deck.allCases {
    print(
        "Deck: \(deck.rawValue), priority: \(deck.evacuationPriority)"
    )
}



// 1.2

enum AlarmLevel: Int {
    case green = 0
    case yellow
    case orange
    case red

    static func level(forTotalMass mass: Int) -> AlarmLevel {
        let steps = mass / 500

        if steps >= 3 {
            return .red
        }

        if let level = AlarmLevel(rawValue: steps) {
            return level
        }

        return .green
    }
}

// Demonstration of AlarmLevel

print(
    "alarm 0 is \(AlarmLevel.level(forTotalMass: 0))"
)

print(
    "alarm 940 is \(AlarmLevel.level(forTotalMass: 940))"
)

print(
    "alarm 4000 is \(AlarmLevel.level(forTotalMass: 4000))"
)



// **MARK: Level 2 · The Manifest**

// 2.1

enum ManifestEntry {
    case crate(id: Int, massKg: Int)
    case container(code: String, massKg: Int)
    case livestock(
        species: String,
        count: Int,
        massPerUnitKg: Int
    )
    case unknown(raw: String)
}



// 2.2

func parseEntry(_ line: String) -> ManifestEntry {
    let parts = fields(line)

    guard let tag = parts.first else {
        return .unknown(raw: line)
    }

    if tag.isEmpty {
        return .unknown(raw: line)
    }

    switch tag {

    case "crate":

        if parts.count != 3 {
            return .unknown(raw: line)
        }

        guard let id = Int(parts[1]) else {
            return .unknown(raw: line)
        }

        guard let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }

        return .crate(
            id: id,
            massKg: massKg
        )

    case "container":

        if parts.count != 3 {
            return .unknown(raw: line)
        }

        if parts[1].isEmpty {
            return .unknown(raw: line)
        }

        guard let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }

        return .container(
            code: parts[1],
            massKg: massKg
        )

    case "livestock":

        if parts.count != 4 {
            return .unknown(raw: line)
        }

        if parts[1].isEmpty {
            return .unknown(raw: line)
        }

        guard let count = Int(parts[2]) else {
            return .unknown(raw: line)
        }

        guard let massPerUnitKg = Int(parts[3]) else {
            return .unknown(raw: line)
        }

        return .livestock(
            species: parts[1],
            count: count,
            massPerUnitKg: massPerUnitKg
        )

    default:
        return .unknown(raw: line)
    }
}



// 2.3

func mass(of entry: ManifestEntry) -> Int {

    switch entry {

    case .crate(_, let massKg):
        return massKg

    case .container(_, let massKg):
        return massKg

    case .livestock(_, let count, let massPerUnitKg):
        return count * massPerUnitKg

    case .unknown:
        return 0
    }
}


// Parse the whole manifest

var totalManifestMass = 0
var unknownCount = 0

for line in rawManifest {

    let entry = parseEntry(line)

    totalManifestMass += mass(of: entry)

    switch entry {

    case .unknown:
        unknownCount += 1

    default:
        break
    }
}

print("total manifest mass \(totalManifestMass)")
print("unknown lines \(unknownCount)")

// A = total manifest mass

let A = totalManifestMass



// **MARK: Level 3 · Crew Snapshots**

// 3.1

struct CrewSnapshot {

    let name: String
    var deck: Deck
    var oxygen: Int

    // oxygen cannot go below zero
    mutating func breathe(_ amount: Int) {

        oxygen -= amount

        if oxygen < 0 {
            oxygen = 0
        }
    }

    // move crew member to another deck
    mutating func move(to deck: Deck) {
        self.deck = deck
    }

    // replace the whole value of self
    mutating func reviveInMedbay() {

        self = CrewSnapshot(
            name: name,
            deck: .medbay,
            oxygen: 100
        )
    }

    // create a rookie crew member
    static func rookie(named name: String) -> CrewSnapshot {

        return CrewSnapshot(
            name: name,
            deck: .bridge,
            oxygen: 100
        )
    }
}



// 3.2

var crewRoster: [CrewSnapshot] = []

for record in crewData {

    guard let deck = Deck(rawValue: record.deck) else {
        print(
            "WARNING: unknown deck \(record.deck) for \(record.name) skipped"
        )
        continue
    }

    let member = CrewSnapshot(
        name: record.name,
        deck: deck,
        oxygen: record.oxygen
    )

    crewRoster.append(member)
}

print("roster built \(crewRoster.count) crew members")



// 3.3 · Value-semantics demonstration

// Copy

let originalSnapshot = crewRoster[0]

var copiedSnapshot = originalSnapshot

let copyBefore = originalSnapshot.oxygen

copiedSnapshot.oxygen = 0

print(
    "copy test before original \(copyBefore)"
)

print(
    "copy test after original \(originalSnapshot.oxygen), copy \(copiedSnapshot.oxygen)"
)


// Plain parameter

func damage(_ member: CrewSnapshot) -> CrewSnapshot {

    var copy = member

    copy.oxygen -= 10

    return copy
}

let plainBefore = originalSnapshot.oxygen

let damagedSnapshot = damage(originalSnapshot)

print(
    "plain parameter before original \(plainBefore)"
)

print(
    "plain parameter after original \(originalSnapshot.oxygen), damaged \(damagedSnapshot.oxygen)"
)


// Inout

func damageInPlace(_ member: inout CrewSnapshot) {

    member.oxygen -= 10
}

var mutableSnapshot = originalSnapshot

let inoutBefore = mutableSnapshot.oxygen

damageInPlace(&mutableSnapshot)

print(
    "inout before \(inoutBefore)"
)

print(
    "inout after \(mutableSnapshot.oxygen)"
)



// **MARK: Level 4 · The Teleport Pod**

// 4.1

final class TeleportPod {

    let id: String

    var chargeLevel: Int

    var occupant: CrewSnapshot?

    init(id: String, chargeLevel: Int) {

        self.id = id
        self.chargeLevel = chargeLevel
        self.occupant = nil
    }

    func load(_ crew: CrewSnapshot) -> Bool {

        if occupant != nil {
            return false
        }

        if chargeLevel < 20 {
            return false
        }

        occupant = crew

        return true
    }

    func fire() -> CrewSnapshot? {

        guard let crew = occupant else {
            return nil
        }

        chargeLevel -= 20
        occupant = nil

        return crew
    }

    // Bonus: deinit
    deinit {
        print("deinit pod \(id)")
    }
}



// 4.2 · Charge ledger: load+fire three times, then fire an empty pod

let chargePod = TeleportPod(
    id: "P-1",
    chargeLevel: 100
)

print(
    "charge start \(chargePod.chargeLevel)"
)

_ = chargePod.load(crewRoster[0])
_ = chargePod.fire()

print(
    "charge after fire 1 \(chargePod.chargeLevel)"
)

_ = chargePod.load(crewRoster[1])
_ = chargePod.fire()

print(
    "charge after fire 2 \(chargePod.chargeLevel)"
)

_ = chargePod.load(crewRoster[2])
_ = chargePod.fire()

print(
    "charge after fire 3 \(chargePod.chargeLevel)"
)

let emptyFireResult = chargePod.fire()

print(
    "charge after empty fire \(chargePod.chargeLevel)"
)

print(
    "empty fire returned nil: \(emptyFireResult == nil)"
)

// C = charge level after the complete sequence

let C = chargePod.chargeLevel



// 4.3 · Reference-semantics demonstration

let podA = TeleportPod(
    id: "A",
    chargeLevel: 100
)

let podB = podA

podB.chargeLevel = 0

print(
    "podA charge \(podA.chargeLevel)"
)

print(
    "podB charge \(podB.chargeLevel)"
)


// Struct comparison

var snapshotA = CrewSnapshot.rookie(
    named: "Dana"
)

var snapshotB = snapshotA

snapshotB.oxygen = 40

print(
    "snapshotA oxygen \(snapshotA.oxygen)"
)

print(
    "snapshotB oxygen \(snapshotB.oxygen)"
)



// **MARK: Level 5 · Station Systems**

// 5.1

final class Station {

    // stored let
    let callSign: String

    // stored var + observers
    var hullIntegrity: Int {

        willSet {
            print(
                "hullIntegrity \(hullIntegrity) -> \(newValue)"
            )
        }

        didSet {

            if hullIntegrity < 0 {
                hullIntegrity = 0
            }

            if hullIntegrity > 100 {
                hullIntegrity = 100
            }
        }
    }

    // lazy stored property
    lazy var fullDiagnostics: String = {

        print("Running full scan...")

        var report = "Diagnostics for \(self.callSign):\n"

        for (deck, oxygen) in self.oxygenByDeck {

            report +=
                "  \(deck.rawValue): \(oxygen)%\n"
        }

        return report
    }()

    // stored dictionary
    var oxygenByDeck: [Deck: Int]

    // computed read-only property
    var totalOxygen: Int {

        var sum = 0

        for oxygen in oxygenByDeck.values {
            sum += oxygen
        }

        return sum
    }

    // computed property with get and set
    var averageOxygen: Int {

        get {

            if oxygenByDeck.isEmpty {
                return 0
            }

            return totalOxygen / oxygenByDeck.count
        }

        set {

            for deck in oxygenByDeck.keys {
                oxygenByDeck[deck] = newValue
            }
        }
    }

    init(
        callSign: String,
        hullIntegrity: Int
    ) {

        self.callSign = callSign
        self.hullIntegrity = hullIntegrity
        self.oxygenByDeck = [:]

        for reading in deckReadings {

            guard let deck = Deck(
                rawValue: reading.deck
            ) else {
                continue
            }

            oxygenByDeck[deck] = reading.oxygen
        }
    }
}



// Create station

let station = Station(
    callSign: "ALMA-7",
    hullIntegrity: 80
)



// Lazy property demonstration

print("--- first fullDiagnostics call ---")

print(
    station.fullDiagnostics
)

print("--- second fullDiagnostics call ---")

print(
    station.fullDiagnostics
)



// B = starting average oxygen

let B = station.averageOxygen

print(
    "average oxygen at start \(B)"
)



// 5.2 · The clamp trap: 130, then -40, then 55

station.hullIntegrity = 130

print(
    "after 130: \(station.hullIntegrity)"
)

station.hullIntegrity = -40

print(
    "after -40: \(station.hullIntegrity)"
)

station.hullIntegrity = 55

print(
    "after 55: \(station.hullIntegrity)"
)



// **MARK: Level 6 · Incident Reports**

// Three of these compile and are wrong. One does not compile.

// For each: expectation, actual behaviour, the language rule, the fix.

/*

// Report 1

var roster = crewRoster

for var member in roster {

    member.oxygen -= 10

}

print(roster[0].oxygen)

// EXPECTATION:
// The author expected the crew to lose oxygen.

// ACTUAL:
// roster is unchanged.

// LANGUAGE RULE:
// `for var member in roster` gives member a copy of each struct value.
// CrewSnapshot is a struct, so it has value semantics.

// FIX:

for i in 0..<roster.count {
    roster[i].oxygen -= 10
}



// Report 2

let podA = TeleportPod(
    id: "A",
    chargeLevel: 100
)

let podB = podA

podB.chargeLevel = 0

print(podA.chargeLevel)

// EXPECTATION:
// The author expected podA to remain 100.

// ACTUAL:
// podA.chargeLevel is 0.

// LANGUAGE RULE:
// TeleportPod is a class, so podA and podB refer to the same object.

// FIX:
// Create another TeleportPod if an independent object is required.


// Report 3

struct Logbook {

    var entries: [String] = []

    func add(_ entry: String) {
        entries.append(entry)
    }
}

// EXPECTATION:
// add should append an entry.

// ACTUAL:
// This does not compile.

// LANGUAGE RULE:
// A struct method that changes stored properties must be marked mutating.

// FIX:

struct FixedLogbook {

    var entries: [String] = []

    mutating func add(_ entry: String) {
        entries.append(entry)
    }
}



// Report 4

let snapshot = CrewSnapshot.rookie(
    named: "Dana"
)

snapshot.oxygen = 40

// This does not compile because snapshot is a let struct value.

// FIX:

var snapshotFixed = CrewSnapshot.rookie(
    named: "Dana"
)

snapshotFixed.oxygen = 40


let pod = TeleportPod(
    id: "B",
    chargeLevel: 50
)

pod.chargeLevel = 10

// This is allowed.

// For a class, let makes the reference constant,
// but the object's var properties can still change.

*/



// **MARK: Level 7 · Sealing the Black Box**

// The leaky original:
//
// class FlightRecorder {
//     var entries: [String] = []
//     var isSealed = false
// }
//
// Your sealed version below.
// One comment per access keyword.

final class FlightRecorder {

    // private:
    // only FlightRecorder can access entries
    private var entries: [String] = []

    // private(set):
    // everyone can read isSealed,
    // but only FlightRecorder can change it
    private(set) var isSealed = false

    // read-only computed property
    var entryCount: Int {
        return entries.count
    }

    // read-only transcript
    var transcript: String {

        var result = ""

        for entry in entries {
            result += entry + "\n"
        }

        return result
    }

    // add entries until recorder is sealed
    func add(_ entry: String) {

        if isSealed {
            return
        }

        entries.append(entry)
    }

    // seal recorder
    func seal() {
        isSealed = true
    }

    // fileprivate:
    // accessible from anywhere in this Swift file
    fileprivate func rawEntry(at index: Int) -> String? {

        if index < 0 {
            return nil
        }

        if index >= entries.count {
            return nil
        }

        return entries[index]
    }
}



// Free function in the same file

func auditTranscript(
    of recorder: FlightRecorder
) -> String {

    var result = ""
    var index = 0

    while let entry = recorder.rawEntry(at: index) {

        result += "[\(index)] \(entry)\n"

        index += 1
    }

    return result
}



// Demonstration of FlightRecorder

let recorder = FlightRecorder()

recorder.add(
    "Teleporter test started"
)

recorder.add(
    "Crew transfer recorded"
)

print(
    "recorder entry count: \(recorder.entryCount)"
)

print(
    "recorder transcript:\n\(recorder.transcript)"
)

print(
    "audit transcript:\n\(auditTranscript(of: recorder))"
)

recorder.seal()

print(
    "recorder sealed: \(recorder.isSealed)"
)

// This entry should not be added because recorder is sealed.

recorder.add(
    "This entry should not be added"
)

print(
    "entry count after sealing: \(recorder.entryCount)"
)

// These would cause compile errors:

// recorder.entries = []

// recorder.isSealed = false



// **MARK: Finale · Integrity Code**

let D = AlarmLevel
    .level(forTotalMass: A)
    .rawValue

let integrityCode = "\(A)-\(B)-\(C)-\(D)"

print(
    "INTEGRITY CODE: \(integrityCode)"
)



// **MARK: Bonus**

// deinit in TeleportPod,
// a do-block lifetime experiment,
// and === identity

print("before do block")

do {

    let temporaryPod = TeleportPod(
        id: "TEMP",
        chargeLevel: 100
    )

    let anotherReference = temporaryPod

    print(
        "inside do: \(temporaryPod.id)"
    )

    print(
        "same object: \(temporaryPod === anotherReference)"
    )
}

print("after do block")



// === identity demonstration

func isSamePod(
    _ first: TeleportPod,
    _ second: TeleportPod
) -> Bool {

    return first === second
}

let podX = TeleportPod(
    id: "X",
    chargeLevel: 100
)

let podY = TeleportPod(
    id: "Y",
    chargeLevel: 100
)

let podZ = podX

print(
    "podX === podY: \(isSamePod(podX, podY))"
)

print(
    "podX === podZ: \(isSamePod(podX, podZ))"
)

// === cannot be used with CrewSnapshot
// because CrewSnapshot is a struct and therefore a value type.



// **MARK: - ================= DEFENSE QUESTIONS =================**

/*

1. Why did CrewSnapshot get an initializer for free and TeleportPod did not?

CrewSnapshot is a struct, so Swift automatically provides a memberwise
initializer for its stored properties when we do not write our own initializer.

TeleportPod is a class, so Swift does not automatically provide a memberwise
initializer. Therefore, we write init ourselves.



2. What does `mutating` do to self, and why do classes never need it?

`mutating` allows a method of a struct to change its stored properties
or replace the whole value of self.

Classes do not need `mutating` because class instances have reference
semantics and their methods can change the object's properties directly.



3. In Report 4 both values are `let`.
What exactly does `let` freeze for a struct, and what does it freeze for a class?

For a struct, `let` makes the whole value immutable, so its var properties
cannot be changed.

For a class, `let` makes the reference constant, but the object itself can
still change its var properties.



4. Why must a lazy property be var?
When does lazy change behaviour, not just performance?

A lazy property must be var because its value is initialized later,
when it is first accessed, and then stored for future accesses.

Lazy changes behaviour when initialization has a side effect.
For example, fullDiagnostics prints "Running full scan..." only on the
first access.



5. private vs fileprivate:
where in your FlightRecorder would private be too strict?

The rawEntry helper is fileprivate because auditTranscript is a free function
outside FlightRecorder but in the same file.

If rawEntry were private, auditTranscript could not call it.

fileprivate allows access from anywhere in the same Swift file.



Bonus.

The deinit of temporaryPod fires after the do block ends because the strong
references temporaryPod and anotherReference both disappear at the end
of the block.

The `===` operator checks whether two class references point to exactly
the same object.

It cannot be used with CrewSnapshot because CrewSnapshot is a struct and
structs are value types, not reference types.

*/
