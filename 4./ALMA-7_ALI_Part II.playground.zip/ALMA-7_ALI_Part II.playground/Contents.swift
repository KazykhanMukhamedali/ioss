// =============================================================
//  Station ALMA-7, Part II: The Teleporter Incident
//  iOS Mobile Development · Module 4 · Lab Assignment
//
//  How to use:
//   • Xcode: File → New → Playground → Blank, replace everything
//     with this file's contents.
//   • Terminal: swift ALMA7_Part2_Starter.swift
//
//  Rules:
//   • Do NOT modify the STARTER DATA section.
//   • `!` (force unwrap) is forbidden: −0.5 points each.
//   • No map / filter / reduce / compactMap.
//   • Default to struct. Use class only where the task says so.
// =============================================================


// MARK: - =================== STARTER DATA ===================
// MARK: - Do not modify anything in this section

/// Splits a line into fields.
func fields(_ line: String, separatedBy separator: Character = ":") -> [String] {
    var result: [String] = []
    var current = ""
    for character in line {
        if character == separator {
            result.append(current)
            current = ""
        } else {
            current.append(character)
        }
    }
    result.append(current)
    return result
}

/// Cargo manifest as recovered from the damaged recorder.
let rawManifest = [
    "crate:101:120",
    "container:KZ-ALM-7:340",
    "livestock:lab mice:12:2",
    "???-corrupted-line",
    "crate:102:75",
    "container:KZ-ALM-9:410",
    "livestock:ficus:3:5",
    "crate:103:260",
    "crate:104:abc",
    ""
]

/// Oxygen readings. One of these deck names is not a real deck.
let deckReadings: [(deck: String, oxygen: Int)] = [
    (deck: "bridge",     oxygen: 78),
    (deck: "lab",        oxygen: 64),
    (deck: "greenhouse", oxygen: 55),
    (deck: "cargo",      oxygen: 12),
    (deck: "medbay",     oxygen: 90),
    (deck: "engine",     oxygen: 41)
]

/// Crew records, straight from the personnel file.
let crewData: [(name: String, deck: String, oxygen: Int)] = [
    (name: "Timur",   deck: "engine", oxygen: 62),
    (name: "Dana",    deck: "lab",    oxygen: 48),
    (name: "Aigerim", deck: "bridge", oxygen: 91),
    (name: "Nurlan",  deck: "cargo",  oxygen: 17)
]

print("ALMA-7 recorder online: \(rawManifest.count) manifest lines, \(deckReadings.count) readings, \(crewData.count) crew records.")

// MARK: - ================= END OF STARTER DATA =================


// MARK: - =================== YOUR SOLUTION ===================


// MARK: Level 1 · The Deck Register

// 1.1 deck это enum со строковым raw value
// raw values swift выведет сам из имён кейсов
enum Deck: String, CaseIterable {
    case bridge
    case lab
    case cargo
    case medbay
    case engine

    // приоритет эвакуации чем меньше число тем раньше спасаем
    var evacuationPriority: Int {
        switch self {
        case .bridge:  return 1
        case .medbay:  return 2
        case .lab:     return 3
        case .engine:  return 4
        case .cargo:   return 5
        }
    }
}

// печатаем все палубы и их приоритет
for deck in Deck.allCases {
    print("deck \(deck.rawValue) priority \(deck.evacuationPriority)")
}

// 1.2 alarm level пишем green = 0 остальные получат raw values сами
enum AlarmLevel: Int {
    case green = 0
    case yellow
    case orange
    case red

    // каждый полный 500 кг это шаг вверх 1500 и выше это red
    static func level(forTotalMass mass: Int) -> AlarmLevel {
        let steps = mass / 500
        if steps >= 3 {
            return .red
        }
        if let level = AlarmLevel(rawValue: steps) {
            return level
        }
        return .green
    }
}

print("alarm 0 is \(AlarmLevel.level(forTotalMass: 0))")
print("alarm 940 is \(AlarmLevel.level(forTotalMass: 940))")
print("alarm 4000 is \(AlarmLevel.level(forTotalMass: 4000))")


// MARK: Level 2 · The Manifest

// 2.1 манифест это enum с associated values
enum ManifestEntry {
    case crate(id: Int, massKg: Int)
    case container(code: String, massKg: Int)
    case livestock(species: String, count: Int, massPerUnitKg: Int)
    case unknown(raw: String)
}

// 2.2 парсим одну строку манифеста
// corrupted line это unknown не nil
func parseEntry(_ line: String) -> ManifestEntry {
    let parts = fields(line)
    guard let tag = parts.first else {
        return .unknown(raw: line)
    }
    if tag.isEmpty {
        return .unknown(raw: line)
    }

    switch tag {
    case "crate":
        if parts.count != 3 {
            return .unknown(raw: line)
        }
        guard let id = Int(parts[1]) else {
            return .unknown(raw: line)
        }
        guard let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .crate(id: id, massKg: massKg)

    case "container":
        if parts.count != 3 {
            return .unknown(raw: line)
        }
        if parts[1].isEmpty {
            return .unknown(raw: line)
        }
        guard let massKg = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        return .container(code: parts[1], massKg: massKg)

    case "livestock":
        if parts.count != 4 {
            return .unknown(raw: line)
        }
        if parts[1].isEmpty {
            return .unknown(raw: line)
        }
        guard let count = Int(parts[2]) else {
            return .unknown(raw: line)
        }
        guard let perUnit = Int(parts[3]) else {
            return .unknown(raw: line)
        }
        return .livestock(species: parts[1], count: count, massPerUnitKg: perUnit)

    default:
        return .unknown(raw: line)
    }
}

// 2.3 масса записи livestock это count * massPerUnitKg
// unknown весит 0
func mass(of entry: ManifestEntry) -> Int {
    switch entry {
    case .crate(_, let massKg):
        return massKg
    case .container(_, let massKg):
        return massKg
    case .livestock(_, let count, let perUnit):
        return count * perUnit
    case .unknown:
        return 0
    }
}

// прогоняем весь манифест
var totalManifestMass = 0
var unknownCount = 0

for line in rawManifest {
    let entry = parseEntry(line)
    totalManifestMass += mass(of: entry)

    switch entry {
    case .unknown:
        unknownCount += 1
    default:
        break
    }
}

print("total manifest mass \(totalManifestMass)")
print("unknown lines \(unknownCount)")

// фрагмент A общая масса манифеста
let A = totalManifestMass


// MARK: Level 3 · Crew Snapshots

// 3.1 структура без init swift сам сделает memberwise init
struct CrewSnapshot {
    let name: String
    var deck: Deck
    var oxygen: Int

    // понижаем кислород но не ниже 0
    mutating func breathe(amount: Int) {
        oxygen -= amount
        if oxygen < 0 {
            oxygen = 0
        }
    }

    // меняем палубу
    mutating func move(to deck: Deck) {
        self.deck = deck
    }

    // присваиваем целый новый self а не по свойствам
    mutating func reviveInMedbay() {
        self = CrewSnapshot(name: name, deck: .medbay, oxygen: 100)
    }

    // статический метод делает новичка
    static func rookie(name: String) -> CrewSnapshot {
        return CrewSnapshot(name: name, deck: .bridge, oxygen: 100)
    }
}

// 3.2 собираем ростер из crewData
// если палуба не существует пропускаем с предупреждением
var crewRoster: [CrewSnapshot] = []
for record in crewData {
    guard let deck = Deck(rawValue: record.deck) else {
        print("WARNING: unknown deck \(record.deck) for \(record.name) skipped")
        continue
    }
    crewRoster.append(CrewSnapshot(name: record.name, deck: deck, oxygen: record.oxygen))
}

print("roster built \(crewRoster.count) crew members")

// 3.3 доказываем что структура это value type
// каждый тест это before и after

// тест 1 копия меняется оригинал нет
let originalSnap = crewRoster[0]
var copySnap = originalSnap
let copyBefore = originalSnap.oxygen
copySnap.oxygen = 0
print("copy test before original \(copyBefore)")
print("copy test after original \(originalSnap.oxygen) copy \(copySnap.oxygen)")

// тест 2 обычная функция меняет копию оригинал нет
func damage(_ member: CrewSnapshot) -> CrewSnapshot {
    var m = member
    m.oxygen -= 10
    return m
}
let plainBefore = originalSnap.oxygen
let damaged = damage(originalSnap)
print("plain test before original \(plainBefore)")
print("plain test after original \(originalSnap.oxygen) damaged \(damaged.oxygen)")

// тест 3 inout меняет оригинал
func damageInPlace(_ member: inout CrewSnapshot) {
    member.oxygen -= 10
}
var mutableSnap = originalSnap
let inoutBefore = mutableSnap.oxygen
damageInPlace(&mutableSnap)
print("inout test before \(inoutBefore)")
print("inout test after \(mutableSnap.oxygen)")


// MARK: Level 4 · The Teleport Pod

// 4.1 класс потому что у него ссылочная семантика
// struct получил init бесплатно а класс нет потому что у классов
// есть наследование и swift не может сам вывести init
final class TeleportPod {
    let id: String
    var chargeLevel: Int
    var occupant: CrewSnapshot?

    init(id: String, chargeLevel: Int) {
        self.id = id
        self.chargeLevel = chargeLevel
        self.occupant = nil
    }

    // грузим если капсула пуста и заряд хватает
    func load(crew: CrewSnapshot) -> Bool {
        if occupant != nil {
            return false
        }
        if chargeLevel < 20 {
            return false
        }
        occupant = crew
        return true
    }

    // если пусто возвращаем nil и заряд не тратим
    // иначе списываем 20 и отдаём пассажира
    func fire() -> CrewSnapshot? {
        guard let crew = occupant else {
            return nil
        }
        chargeLevel -= 20
        occupant = nil
        return crew
    }
}

// 4.2 леджер заряда
// 100 -> 80 -> 60 -> 40 -> 40
let pod = TeleportPod(id: "P-1", chargeLevel: 100)
print("charge after start \(pod.chargeLevel)")

_ = pod.load(crew: crewRoster[0])
_ = pod.fire()
print("charge after step 1 \(pod.chargeLevel)")

_ = pod.load(crew: crewRoster[1])
_ = pod.fire()
print("charge after step 2 \(pod.chargeLevel)")

_ = pod.load(crew: crewRoster[2])
_ = pod.fire()
print("charge after step 3 \(pod.chargeLevel)")

let emptyResult = pod.fire()
print("charge after empty fire \(pod.chargeLevel) returned nil \(emptyResult == nil)")

// фрагмент C заряд капсулы после всей последовательности
let C = pod.chargeLevel

// 4.3 доказываем что класс это reference type
let podA = TeleportPod(id: "A", chargeLevel: 100)
let podB = podA
podB.chargeLevel = 0
print("podA \(podA.chargeLevel) podB \(podB.chargeLevel)")

var snapA = CrewSnapshot.rookie(name: "Dana")
var snapB = snapA
snapB.oxygen = 40
print("snapA \(snapA.oxygen) snapB \(snapB.oxygen)")

// классы это ссылки структуры это значения


// MARK: Level 5 · Station Systems

// 5.1 класс станции со всеми видами свойств
final class Station {
    // stored let
    let callSign: String

    // stored var с observers
    var hullIntegrity: Int {
        willSet {
            print("hullIntegrity \(hullIntegrity) -> \(newValue)")
        }
        didSet {
            if hullIntegrity < 0 {
                hullIntegrity = 0
            }
            if hullIntegrity > 100 {
                hullIntegrity = 100
            }
        }
    }

    // lazy stored вычислится один раз при первом обращении
    lazy var fullDiagnostics: String = {
        print("Running full scan...")
        var report = "Diagnostics for \(self.callSign):\n"
        for (deck, oxygen) in self.oxygenByDeck {
            report += "  \(deck.rawValue): \(oxygen)%\n"
        }
        return report
    }()

    // stored словарь палуб
    var oxygenByDeck: [Deck: Int]

    // computed read only без get
    var totalOxygen: Int {
        var sum = 0
        for value in oxygenByDeck.values {
            sum += value
        }
        return sum
    }

    // computed get + set
    var averageOxygen: Int {
        get {
            if oxygenByDeck.isEmpty {
                return 0
            }
            return totalOxygen / oxygenByDeck.count
        }
        set {
            for deck in oxygenByDeck.keys {
                oxygenByDeck[deck] = newValue
            }
        }
    }

    init(callSign: String, hullIntegrity: Int) {
        self.callSign = callSign
        self.hullIntegrity = hullIntegrity
        self.oxygenByDeck = [:]

        // палубы которых нет в enum пропускаем
        for reading in deckReadings {
            guard let deck = Deck(rawValue: reading.deck) else {
                continue
            }
            oxygenByDeck[deck] = reading.oxygen
        }
    }
}

let station = Station(callSign: "ALMA-7", hullIntegrity: 80)

// доказываем что lazy печатает только один раз
print("--- first fullDiagnostics call ---")
print(station.fullDiagnostics)
print("--- second fullDiagnostics call ---")
print(station.fullDiagnostics)

// фрагмент B средний кислород на старте
let B = station.averageOxygen
print("averageOxygen at start \(B)")

// 5.2 clamp trap
station.hullIntegrity = 130
print("after 130 \(station.hullIntegrity)")

station.hullIntegrity = -40
print("after -40 \(station.hullIntegrity)")

station.hullIntegrity = 55
print("after 55 \(station.hullIntegrity)")

// didSet не зацикливается потому что присваивание внутри didSet
// не запускает didSet снова


// MARK: Level 6 · Incident Reports

/*
// report 1 компилируется но лжёт
// ожидалось кислород у всех упал
// реально roster[0].oxygen не изменился
// правило for var member делает копию элемента
// фикс
//   for i in 0..<roster.count {
//       roster[i].oxygen -= 10
//   }

// report 2 компилируется но лжёт
// ожидалось podA.chargeLevel 100
// реально 0
// правило классы ссылочная семантика podA и podB это один объект
// фикс не менять через вторую ссылку или сделать копию

// report 3 не компилируется
// ожидалось add добавляет запись
// реально ошибка cannot use mutating member on immutable value
// правило метод структуры меняющий stored property должен быть mutating
// фикс
//   mutating func add(_ entry: String) {
//       entries.append(entry)
//   }

// report 4 компилируется но одна строка ошибочна
// snapshot.oxygen = 40 ошибка потому что snapshot объявлен let
// правило для структуры let замораживает все свойства
// фикс var snapshot
// pod.chargeLevel = 10 ок потому что для класса let замораживает только ссылку
*/


// MARK: Level 7 · Sealing the Black Box

final class FlightRecorder {
    // private снаружи не видно и заменить нельзя
    private var entries: [String] = []

    // private(set) читать можно менять снаружи нельзя
    private(set) var isSealed = false

    var entryCount: Int {
        return entries.count
    }

    var transcript: String {
        var result = ""
        for entry in entries {
            result += entry + "\n"
        }
        return result
    }

    func add(_ entry: String) {
        if isSealed {
            return
        }
        entries.append(entry)
    }

    func seal() {
        isSealed = true
    }

    // fileprivate доступно в этом файле но не в других модулях
    fileprivate func rawEntry(at index: Int) -> String? {
        if index < 0 {
            return nil
        }
        if index >= entries.count {
            return nil
        }
        return entries[index]
    }
}

// свободная функция в этом же файле использует fileprivate helper
func auditTranscript(of recorder: FlightRecorder) -> String {
    var result = ""
    var i = 0
    while let entry = recorder.rawEntry(at: i) {
        result += "[\(i)] \(entry)\n"
        i += 1
    }
    return result
}

// попытка взлома
// r.entries = []      // error: 'entries' is inaccessible due to 'private' protection level
// r.isSealed = false  // error: cannot assign to property: 'isSealed' is a get-only property


// MARK: Finale · Integrity Code

// фрагмент D raw value уровня тревоги для массы A
let D = AlarmLevel.level(forTotalMass: A).rawValue
let integrityCode = "\(A)-\(B)-\(C)-\(D)"
print("INTEGRITY CODE: \(integrityCode)")


// MARK: Bonus

// deinit в отдельном классе чтобы показать как работает
final class TrackedPod {
    let id: String

    init(id: String) {
        self.id = id
    }

    deinit {
        print("deinit pod \(id)")
    }
}

print("before do")
do {
    let p = TrackedPod(id: "X")
    let pRef = p
    print("inside do \(p.id) \(pRef.id)")
}
print("after do")

// === это оператор тождества ссылок
func isSamePod(_ a: TeleportPod, _ b: TeleportPod) -> Bool {
    return a === b
}

let podX = TeleportPod(id: "X", chargeLevel: 100)
let podY = TeleportPod(id: "X", chargeLevel: 100)
let podZ = podX

print("podX === podY \(isSamePod(podX, podY))")
print("podX === podZ \(isSamePod(podX, podZ))")

// === нельзя к CrewSnapshot потому что это оператор тождества ссылок
// а структура это value type у неё нет идентичности


// MARK: - ================= DEFENSE QUESTIONS =================
/*
 1 CrewSnapshot структура Swift сам делает memberwise init
 TeleportPod класс у классов нет memberwise init потому что есть наследование

 2 mutating говорит что метод меняет self
 для структуры self inout метод меняет копию и записывает обратно
 классы ссылочный тип свойства можно менять через let ссылку
 поэтому mutating не нужен

 3 для структуры let замораживает все свойства
 для класса let замораживает только ссылку свойства менять можно

 4 lazy должен быть var потому что значение сохраняется при первом обращении
 lazy меняет поведение если вычисление имеет побочный эффект
 например печатает что то только при первом обращении

 5 entries объявлен private но свободная функция auditTranscript
 в том же файле хочет читать записи private её заблокирует
 fileprivate разрешает доступ в пределах файла

 Bonus deinit срабатывает после выхода из do когда обе ссылки
 вышли из scope и счётчик стал 0
 === нельзя к CrewSnapshot потому что это оператор тождества ссылок
 а структура value type
*/
